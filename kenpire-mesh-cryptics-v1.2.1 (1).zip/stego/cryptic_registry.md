# Cryptic Registry
- release: v1.2.1
- file: chapter_one_bundle/poster_cryptic.png
- actor: RoosterOps
- command: /pulse morning
